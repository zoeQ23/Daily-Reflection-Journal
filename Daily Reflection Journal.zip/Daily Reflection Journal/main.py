from ui.daily_entry_form import launch_daily_entry_form

if __name__ == "__main__":
    launch_daily_entry_form() 